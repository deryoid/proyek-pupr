# CRUD SQLite

## Tutorial ##
https://dedykuncoro.com/2016/12/android-tutorial-crud-sqlite-database.html

## Demo App ##
https://www.youtube.com/watch?v=FwHUvvyp_kc